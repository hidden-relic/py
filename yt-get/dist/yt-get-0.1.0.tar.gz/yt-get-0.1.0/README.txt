yt-get is a Youtube audio CLI Downloading helper. You can search by title,
or you can give it a direct URL.

COMMANDS:

Enter a few words from the title of the video you want, and a list of results will print out.
Choose the correct video by typing the number of the video in the list. The video will be added to the download list for audio extraction.

L toggles "I'm Feeling Lucky" mode, which when active will add the first result from the list to the download list, without showing the list.

P tells yt-get that the next URL entered will be that of a Playlist. yt-get will then
add all the videos in the playlist to the download queue.

D will begin downloading all the audios in the queue

Q will exit the app 
